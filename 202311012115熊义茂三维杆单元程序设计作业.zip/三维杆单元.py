import numpy as np


def as_vector(name, value, length):
    """
    将输入转换为一维 NumPy 数组，并检查长度。
    """
    arr = np.asarray(value, dtype=float).reshape(-1)

    if arr.size != length:
        raise ValueError(f"{name} 必须包含 {length} 个数值。")

    return arr


def fmt_float(x):
    """
    控制浮点数输出格式，避免出现 -0.00000e+00。
    """
    if abs(x) < 1.0e-14:
        x = 0.0
    return f"{x:12.5e}"


def print_array(name, arr):
    """
    打印向量或矩阵。
    """
    print(f"{name} =")
    print(np.array2string(
        np.asarray(arr),
        formatter={"float_kind": fmt_float},
        max_line_width=120
    ))


def truss3d_element_stiffness(x1, x2, E, A, tol=1.0e-12):
    """
    计算三维杆单元 / 空间桁架单元的长度、方向余弦和全局刚度矩阵。

    参数
    ----
    x1, x2 : list or array
        两个节点坐标，例如 [x, y, z]，单位 m。
    E : float
        弹性模量，单位 Pa。
    A : float
        截面积，单位 m^2。
    tol : float
        判断退化单元的容差。

    返回
    ----
    L : float
        单元长度，单位 m。
    direction_cosines : ndarray
        方向余弦 [cx, cy, cz]。
    Ke : ndarray
        6 x 6 单元刚度矩阵，单位 N/m。
    """
    x1 = as_vector("x1", x1, 3)
    x2 = as_vector("x2", x2, 3)

    E = float(E)
    A = float(A)

    if E <= 0:
        raise ValueError("弹性模量 E 必须为正数。")

    if A <= 0:
        raise ValueError("截面积 A 必须为正数。")

    dx = x2 - x1
    L = np.linalg.norm(dx)

    if L <= tol:
        raise ValueError("退化单元：两个节点重合或距离过小，无法计算。")

    direction_cosines = dx / L
    cx, cy, cz = direction_cosines

    b = np.array([-cx, -cy, -cz, cx, cy, cz], dtype=float)

    Ke = (E * A / L) * np.outer(b, b)

    return L, direction_cosines, Ke


def truss3d_element_stress(x1, x2, E, A, de):
    """
    根据节点位移计算三维杆单元的轴向应变、应力和轴力。

    参数
    ----
    x1, x2 : list or array
        两个节点坐标，单位 m。
    E : float
        弹性模量，单位 Pa。
    A : float
        截面积，单位 m^2。
    de : list or array
        单元节点位移列阵：
        [u1, v1, w1, u2, v2, w2]，单位 m。

    返回
    ----
    epsilon : float
        轴向应变。
    sigma : float
        轴向应力，单位 Pa。
    N : float
        轴力，单位 N。
    """
    L, direction_cosines, _ = truss3d_element_stiffness(x1, x2, E, A)
    de = as_vector("de", de, 6)

    cx, cy, cz = direction_cosines

    b = np.array([-cx, -cy, -cz, cx, cy, cz], dtype=float)

    axial_elongation = b @ de
    epsilon = axial_elongation / L
    sigma = E * epsilon
    N = sigma * A

    return epsilon, sigma, N


def internal_force(Ke, de):
    """
    计算单元节点力列阵 Fe = Ke * de。
    """
    de = as_vector("de", de, 6)
    return Ke @ de


def check_element_properties(Ke, title):
    """
    检查刚度矩阵的对称性、半正定性和奇异性。
    """
    print()
    print(f"{title}：刚度矩阵性质检查")
    print("-" * 70)

    is_symmetric = np.allclose(Ke, Ke.T, rtol=1.0e-10, atol=1.0e-8)
    print(f"Ke 是否对称：{is_symmetric}")

    eigenvalues = np.linalg.eigvalsh(Ke)
    print_array("Ke 的特征值", eigenvalues)

    tol = max(1.0, np.max(np.abs(eigenvalues))) * 1.0e-10
    is_positive_semidefinite = np.all(eigenvalues >= -tol)
    print(f"Ke 是否半正定：{is_positive_semidefinite}")

    rank = np.linalg.matrix_rank(Ke, tol=tol)
    print(f"Ke 的数值秩：{rank}")

    print("说明：")
    print("单个自由三维杆单元只抵抗杆轴方向的拉压变形。")
    print("对于刚体平移、横向零能量位移等变形模式，杆件不产生轴向伸长。")
    print("因此单个自由杆单元的刚度矩阵存在零特征值，是奇异矩阵。")
    print("特征值中若出现极小负数，一般是浮点舍入误差导致。")


def check_rigid_body_translation(Ke):
    """
    检查刚体平移位移是否不产生内力。
    """
    print()
    print("刚体平移检查")
    print("-" * 70)

    de_rigid = np.array([
        1.0e-3, 2.0e-3, -1.5e-3,
        1.0e-3, 2.0e-3, -1.5e-3
    ])

    Fe = internal_force(Ke, de_rigid)

    print_array("刚体平移位移 de_rigid", de_rigid)
    print_array("Fe = Ke @ de_rigid", Fe)

    is_zero_force = np.allclose(Fe, np.zeros(6), atol=1.0e-8)
    print(f"刚体平移是否不产生内力：{is_zero_force}")


def verify_column_meaning(Ke, j=3):
    """
    验证刚度矩阵第 j 列的物理意义。

    注意：
    Python 下标从 0 开始。
    j = 3 表示第 4 个自由度，即 u2。
    """
    print()
    print("刚度矩阵物理意义验证")
    print("-" * 70)

    de = np.zeros(6)
    de[j] = 1.0

    Fe = internal_force(Ke, de)

    print(f"选取第 {j + 1} 个自由度，令该自由度位移为 1，其余自由度位移为 0。")
    print_array("de", de)
    print_array("Fe = Ke @ de", Fe)
    print_array(f"Ke 的第 {j + 1} 列", Ke[:, j])

    print(f"Fe 是否等于 Ke 的第 {j + 1} 列：{np.allclose(Fe, Ke[:, j])}")
    print("结论：")
    print("刚度矩阵第 j 列表示：")
    print("当第 j 个自由度发生单位位移、其他自由度固定时，")
    print("各自由度上产生的节点力。")


def run_case(case_name, x1, x2, E, A, de):
    """
    运行一个验证算例。
    """
    print()
    print("=" * 70)
    print(case_name)
    print("=" * 70)

    L, direction_cosines, Ke = truss3d_element_stiffness(x1, x2, E, A)
    epsilon, sigma, N = truss3d_element_stress(x1, x2, E, A, de)

    print(f"节点 1 坐标 x1 = {x1}")
    print(f"节点 2 坐标 x2 = {x2}")
    print(f"E = {E:.6e} Pa")
    print(f"A = {A:.6e} m^2")
    print(f"单元长度 L = {L:.12g} m")
    print(
        "方向余弦 (cx, cy, cz) = "
        f"({direction_cosines[0]:.12g}, "
        f"{direction_cosines[1]:.12g}, "
        f"{direction_cosines[2]:.12g})"
    )

    print_array("Ke", Ke)
    print_array("节点位移 de", de)

    print(f"轴向应变 epsilon = {epsilon:.12e}")
    print(f"轴向应力 sigma = {sigma:.12e} Pa = {sigma / 1.0e6:.12g} MPa")
    print(f"轴力 N = {N:.12e} N")

    check_element_properties(Ke, case_name)

    return L, direction_cosines, Ke, epsilon, sigma, N


def check_degenerate_element():
    """
    检查退化单元。
    """
    print()
    print("退化单元检查")
    print("-" * 70)

    try:
        truss3d_element_stiffness(
            [0.0, 0.0, 0.0],
            [0.0, 0.0, 0.0],
            210.0e9,
            1.0e-4
        )
    except ValueError as err:
        print(f"捕获到错误：{err}")


def main():
    np.set_printoptions(linewidth=120, suppress=False)

    # ================================================================
    # 算例 1：沿 x 轴的一维杆单元
    # ================================================================
    x1_1 = [0.0, 0.0, 0.0]
    x2_1 = [2.0, 0.0, 0.0]
    E_1 = 200.0e9
    A_1 = 1.0e-4
    de_1 = [0.0, 0.0, 0.0, 1.0e-3, 0.0, 0.0]

    _, _, Ke1, _, _, _ = run_case(
        "算例 1：沿 x 轴的一维杆单元",
        x1_1,
        x2_1,
        E_1,
        A_1,
        de_1
    )

    # ================================================================
    # 算例 2：空间任意方向杆单元
    # ================================================================
    x1_2 = [0.0, 0.0, 0.0]
    x2_2 = [1.0, 2.0, 2.0]
    E_2 = 210.0e9
    A_2 = 2.0e-4
    de_2 = [0.0, 0.0, 0.0, 1.0e-3, 2.0e-3, 2.0e-3]

    _, _, Ke2, _, _, _ = run_case(
        "算例 2：空间任意方向杆单元",
        x1_2,
        x2_2,
        E_2,
        A_2,
        de_2
    )

    # ================================================================
    # 算例 2 的附加验证：刚体平移不产生内力
    # ================================================================
    check_rigid_body_translation(Ke2)

    # ================================================================
    # 刚度矩阵物理意义验证
    # 这里选择第 4 个自由度，即节点 2 的 x 向位移 u2
    # ================================================================
    verify_column_meaning(Ke2, j=3)

    # ================================================================
    # 退化单元检查
    # ================================================================
    check_degenerate_element()


if __name__ == "__main__":
    main()