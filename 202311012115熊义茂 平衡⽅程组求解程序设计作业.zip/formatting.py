# -*- coding: utf-8 -*-
"""文本输出格式化辅助函数。"""

from __future__ import annotations

import numpy as np


def matrix_to_string(A, digits=6):
    return np.array2string(
        np.array(A, dtype=float),
        precision=digits,
        suppress_small=False,
        separator=", ",
        max_line_width=200,
    )


def vector_to_string(v, digits=6):
    return np.array2string(
        np.array(v, dtype=float),
        precision=digits,
        suppress_small=False,
        separator=", ",
        max_line_width=200,
    )
