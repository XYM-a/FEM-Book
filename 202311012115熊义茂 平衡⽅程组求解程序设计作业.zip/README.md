# 有限元平衡方程组求解与误差分析程序设计作业

本工程对应第 2.4 节“平衡方程组的求解”。程序复用 2.3 作业中的有限元组装流程，并新增 LDL^T 分解求解器、误差分析、多载荷工况效率比较和 Poisson 方程稀疏求解算例。

## 1. 环境要求

建议使用 Python 3.9 及以上版本。

需要安装：

```bash
pip install -r requirements.txt
```

如果安装了 `pypardiso`，Poisson 算例会优先调用 MKL PARDISO；如果未安装，程序会自动使用 `SciPy/SuperLU` 稀疏直接求解器。

## 2. 一键运行全部算例

在 PyCharm 或命令行中打开本文件夹，然后运行：

```bash
python run_all.py
```

运行结果会输出到 `outputs` 文件夹，Poisson 方程图像会输出到 `figures` 文件夹。

## 3. 主要文件说明

```text
ldlt_solver.py          LDL^T 分解、前代、对角求解、回代和残差计算
fem_model.py            读取有限元 JSON 输入文件并生成 LM 对号矩阵
fem_element.py          计算杆/桁架单元几何和刚度矩阵
fem_assembly.py         组装总体刚度矩阵
fem_solver.py           生成缩减方程并调用 LDL^T 求解器
fem_postprocess.py      计算单元应力和轴力
error_analysis.py       病态矩阵误差分析
sparse_poisson_q4.py    Q4 有限元 Poisson 方程稀疏求解
formatting.py           输出格式化辅助函数
run_all.py              运行全部验证算例
```

## 4. 输入文件

输入文件位于 `examples` 文件夹：

```text
rod_1d.json             一维两单元杆结构
truss_2d.json           二维两杆桁架结构
indefinite_matrix.json  非正定矩阵检测算例
```

三对角矩阵、病态矩阵、多载荷工况和 Poisson 方程算例由程序自动生成。

## 5. 输出文件

`outputs` 文件夹中包含主要运行结果：

```text
rod_1d_output.txt              一维杆结构结果
truss_2d_output.txt            二维桁架结构结果
tridiagonal_output.txt         三对角矩阵结果
nonpositive_pivot_output.txt   非正主元检测结果
ill_conditioned_output.txt     病态矩阵误差分析结果
multi_load_output.txt          多载荷工况效率比较
poisson_output.txt             Poisson 方程求解结果
run_all_output.txt             所有结果汇总
```

`figures` 文件夹中包含 Poisson 方程的数值解图和误差图。

## 6. 报告

`report.docx` 为作业报告。

## 7. 说明

核心 LDL^T 求解器没有使用 `numpy.linalg.solve` 或 `scipy.linalg.solve` 完成求解。NumPy 只用于数组存储、矩阵乘法、范数和结果检查。大规模稀疏 Poisson 算例使用 SciPy/SuperLU 或可选的 pypardiso/MKL PARDISO。
