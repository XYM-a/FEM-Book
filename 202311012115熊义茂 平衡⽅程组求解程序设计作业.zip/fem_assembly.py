# -*- coding: utf-8 -*-
"""总体刚度矩阵直接组装模块。"""

from __future__ import annotations

import numpy as np

from fem_element import element_stiffness
from fem_model import FEMModel


def assemble_global_stiffness(model: FEMModel):
    """根据 LM 矩阵把各单元刚度矩阵直接组装到总体刚度矩阵中。"""
    element_data = []
    for e in range(model.nel):
        ke, L, gamma = element_stiffness(model, e)
        lm = model.LM[:, e]
        model.K[np.ix_(lm, lm)] += ke
        element_data.append({"ke": ke, "length": L, "gamma": gamma})
    return model.K, element_data
