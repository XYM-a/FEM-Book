# -*- coding: utf-8 -*-
"""病态矩阵误差分析算例。"""

from __future__ import annotations

import math
import numpy as np

from ldlt_solver import ldlt_factor, ldlt_solve, residual_norm, LDLTError


def round_sig(x, sig=4):
    """把数值四舍五入到指定有效数字。"""
    x = float(x)
    if x == 0.0:
        return 0.0
    return round(x, sig - int(math.floor(math.log10(abs(x)))) - 1)


def rounded_ldlt_factor(K, sig=4, tol=1.0e-12):
    """带人为四位有效数字舍入的 LDL^T 分解，用于误差演示。"""
    A = np.array(K, dtype=float)
    n = A.shape[0]
    L = np.eye(n)
    D = np.zeros(n)
    for j in range(n):
        s = 0.0
        for k in range(j):
            s = round_sig(s + round_sig(L[j, k] * L[j, k] * D[k], sig), sig)
        D[j] = round_sig(A[j, j] - s, sig)
        if D[j] <= tol:
            raise LDLTError(f"四位有效数字下出现非正主元：第 {j+1} 个主元 = {D[j]}")
        for i in range(j + 1, n):
            s = 0.0
            for k in range(j):
                s = round_sig(s + round_sig(L[i, k] * D[k] * L[j, k], sig), sig)
            L[i, j] = round_sig(round_sig(A[i, j] - s, sig) / D[j], sig)
    return L, D


def rounded_ldlt_solve(L, D, R, sig=4):
    """带人为四位有效数字舍入的前代、对角求解、回代。"""
    R = np.array(R, dtype=float)
    n = len(R)
    y = np.zeros(n)
    for i in range(n):
        s = 0.0
        for j in range(i):
            s = round_sig(s + round_sig(L[i, j] * y[j], sig), sig)
        y[i] = round_sig(R[i] - s, sig)

    z = np.zeros(n)
    for i in range(n):
        z[i] = round_sig(y[i] / D[i], sig)

    a = np.zeros(n)
    for i in range(n - 1, -1, -1):
        s = 0.0
        for j in range(i + 1, n):
            s = round_sig(s + round_sig(L[j, i] * a[j], sig), sig)
        a[i] = round_sig(z[i] - s, sig)
    return a


def analyze_ill_conditioned():
    """返回病态矩阵的双精度、低精度输入扰动和 float16 对比结果。"""
    K = np.array([[1.0000, 1.0000], [1.0000, 1.0001]], dtype=float)
    a_exact = np.array([1.0, 1.0])
    R = K @ a_exact
    cond = float(np.linalg.cond(K))

    rows = []

    # 双精度 LDL^T
    L, D = ldlt_factor(K)
    a = ldlt_solve(L, D, R)
    r, nr, rr = residual_norm(K, a, R)
    er = float(np.linalg.norm(a - a_exact) / np.linalg.norm(a_exact))
    rows.append({"case": "双精度 LDL^T", "a": a, "residual": r, "relative_residual": rr, "relative_error": er})

    # 只把右端项保留 4 位有效数字：2.0001 被截断为 2.000，解会明显偏离。
    R4 = np.array([round_sig(v, 4) for v in R], dtype=float)
    a4_rhs = ldlt_solve(L, D, R4)
    r4_rhs, nr4_rhs, rr4_rhs = residual_norm(K, a4_rhs, R)
    er4_rhs = float(np.linalg.norm(a4_rhs - a_exact) / np.linalg.norm(a_exact))
    rows.append({"case": "右端项保留四位有效数字", "a": a4_rhs, "residual": r4_rhs, "relative_residual": rr4_rhs, "relative_error": er4_rhs})

    # 把 K 和 R 都保留 4 位有效数字：K[1,1]=1.0001 会变成 1.000，矩阵退化为奇异矩阵。
    K4 = np.array([[round_sig(v, 4) for v in row] for row in K], dtype=float)
    R4_all = np.array([round_sig(v, 4) for v in R], dtype=float)
    try:
        L4, D4 = ldlt_factor(K4, tol=1.0e-12)
        a4 = ldlt_solve(L4, D4, R4_all)
        msg = "成功"
    except Exception as exc:
        a4 = np.array([np.nan, np.nan])
        msg = str(exc)
    if np.all(np.isfinite(a4)):
        r4, nr4, rr4 = residual_norm(K, a4, R)
        er4 = float(np.linalg.norm(a4 - a_exact) / np.linalg.norm(a_exact))
    else:
        r4 = np.array([np.nan, np.nan])
        rr4 = np.nan
        er4 = np.nan
    rows.append({"case": f"K 和 R 均保留四位有效数字：{msg}", "a": a4, "residual": r4, "relative_residual": rr4, "relative_error": er4})

    # float16 计算。矩阵本身在 float16 下会丢失 0.0001 差异，因此矩阵近似奇异。
    K16 = K.astype(np.float16)
    R16 = R.astype(np.float16)
    try:
        L16, D16 = ldlt_factor(K16.astype(float), tol=1.0e-8)
        a16 = ldlt_solve(L16, D16, R16.astype(float))
        msg = "成功"
    except Exception as exc:
        a16 = np.array([np.nan, np.nan])
        msg = str(exc)
    if np.all(np.isfinite(a16)):
        r16, nr16, rr16 = residual_norm(K, a16, R)
        er16 = float(np.linalg.norm(a16 - a_exact) / np.linalg.norm(a_exact))
    else:
        r16 = np.array([np.nan, np.nan])
        rr16 = np.nan
        er16 = np.nan
    rows.append({"case": f"float16 演示：{msg}", "a": a16, "residual": r16, "relative_residual": rr16, "relative_error": er16})

    return K, R, a_exact, cond, rows
