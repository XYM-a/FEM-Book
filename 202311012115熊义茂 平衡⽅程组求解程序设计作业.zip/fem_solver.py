# -*- coding: utf-8 -*-
"""有限元缩减平衡方程求解模块。"""

from __future__ import annotations

import numpy as np

from fem_assembly import assemble_global_stiffness
from fem_model import FEMModel, free_dofs
from ldlt_solver import solve_equilibrium, residual_norm


def solve_fem_model(model: FEMModel, method: str = "ldlt"):
    """组装并求解有限元模型。"""
    K_full, element_data = assemble_global_stiffness(model)
    fixed = model.fixed_dof
    free = free_dofs(model)

    K_FF = K_full[np.ix_(free, free)]
    K_FE = K_full[np.ix_(free, fixed)]
    d_E = model.d[fixed]
    f_F = model.f[free]
    rhs = f_F - K_FE @ d_E

    d_F, info = solve_equilibrium(K_FF, rhs, method=method)
    model.d[free] = d_F
    model.d[fixed] = d_E

    reactions = K_full @ model.d - model.f
    r_red, norm_r, rel_r = residual_norm(K_FF, d_F, rhs)

    return {
        "K": K_full,
        "K_FF": K_FF,
        "rhs": rhs,
        "free_dof": free,
        "fixed_dof": fixed,
        "d": model.d,
        "reactions": reactions,
        "element_data": element_data,
        "solver_info": info,
        "reduced_residual": r_red,
        "reduced_residual_norm": norm_r,
        "reduced_relative_residual": rel_r,
    }
