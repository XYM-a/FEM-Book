# -*- coding: utf-8 -*-
"""
LDL^T 求解器模块

本模块只使用 NumPy 的基础数组运算，不调用 numpy.linalg.solve 完成核心求解。
适用于对称正定线性方程组 K a = R。
"""

from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Optional, Tuple

import numpy as np


class LDLTError(RuntimeError):
    """LDL^T 分解失败时抛出的错误。"""


@dataclass
class SolverInfo:
    """求解器运行信息。"""

    method: str
    success: bool
    factor_time: float = 0.0
    solve_time: float = 0.0
    min_pivot: Optional[float] = None
    message: str = ""


def _as_float_array(A: np.ndarray) -> np.ndarray:
    """复制为双精度数组，避免修改原始输入。"""
    return np.array(A, dtype=float, copy=True)


def ldlt_factor(K: np.ndarray, tol: float = 1.0e-12) -> Tuple[np.ndarray, np.ndarray]:
    """
    对称正定矩阵的 LDL^T 分解。

    参数
    ----
    K : ndarray, shape (n, n)
        对称矩阵。
    tol : float
        主元检查容许阈值。

    返回
    ----
    L : ndarray, shape (n, n)
        单位下三角矩阵。
    D : ndarray, shape (n,)
        对角矩阵 D 的对角元素。

    说明
    ----
    分解公式：K = L D L^T。
    若出现 D[j] <= tol，则认为矩阵非正定或存在零主元。
    """
    A = _as_float_array(K)
    if A.ndim != 2 or A.shape[0] != A.shape[1]:
        raise ValueError("K 必须是方阵。")

    n = A.shape[0]
    if not np.allclose(A, A.T, atol=1.0e-10):
        raise ValueError("K 不是对称矩阵，不能使用本 LDL^T 求解器。")

    L = np.eye(n, dtype=float)
    D = np.zeros(n, dtype=float)

    for j in range(n):
        # 计算第 j 个主元 D[j]
        s = 0.0
        for k in range(j):
            s += L[j, k] * L[j, k] * D[k]
        D[j] = A[j, j] - s

        if D[j] <= tol:
            raise LDLTError(
                f"矩阵非正定或存在零主元：第 {j + 1} 个主元 D[{j}] = {D[j]:.6e}"
            )

        # 计算 L 的第 j 列
        for i in range(j + 1, n):
            s = 0.0
            for k in range(j):
                s += L[i, k] * D[k] * L[j, k]
            L[i, j] = (A[i, j] - s) / D[j]

    return L, D


def forward_substitution_unit_lower(L: np.ndarray, R: np.ndarray) -> np.ndarray:
    """求解 L y = R，其中 L 为单位下三角矩阵。支持单个或多个右端项。"""
    B = np.array(R, dtype=float, copy=True)
    one_dim = B.ndim == 1
    if one_dim:
        B = B.reshape(-1, 1)

    n, nrhs = B.shape
    y = np.zeros((n, nrhs), dtype=float)
    for i in range(n):
        for col in range(nrhs):
            s = 0.0
            for j in range(i):
                s += L[i, j] * y[j, col]
            y[i, col] = B[i, col] - s

    return y.ravel() if one_dim else y


def diagonal_solve(D: np.ndarray, y: np.ndarray) -> np.ndarray:
    """求解 D z = y，其中 D 为对角矩阵的对角元素。"""
    Y = np.array(y, dtype=float, copy=True)
    one_dim = Y.ndim == 1
    if one_dim:
        Y = Y.reshape(-1, 1)

    z = np.zeros_like(Y)
    for i in range(len(D)):
        z[i, :] = Y[i, :] / D[i]

    return z.ravel() if one_dim else z


def back_substitution_unit_upper_from_L(L: np.ndarray, z: np.ndarray) -> np.ndarray:
    """求解 L^T a = z。支持单个或多个右端项。"""
    Z = np.array(z, dtype=float, copy=True)
    one_dim = Z.ndim == 1
    if one_dim:
        Z = Z.reshape(-1, 1)

    n, nrhs = Z.shape
    a = np.zeros((n, nrhs), dtype=float)
    for i in range(n - 1, -1, -1):
        for col in range(nrhs):
            s = 0.0
            for j in range(i + 1, n):
                s += L[j, i] * a[j, col]
            a[i, col] = Z[i, col] - s

    return a.ravel() if one_dim else a


def ldlt_solve(L: np.ndarray, D: np.ndarray, R: np.ndarray) -> np.ndarray:
    """
    用 LDL^T 分解结果求解 K a = R。

    步骤为：
    1. 前代：L y = R
    2. 对角求解：D z = y
    3. 回代：L^T a = z
    """
    y = forward_substitution_unit_lower(L, R)
    z = diagonal_solve(D, y)
    a = back_substitution_unit_upper_from_L(L, z)
    return a


def solve_equilibrium(K: np.ndarray, R: np.ndarray, method: str = "ldlt", **options):
    """
    统一线性方程组求解接口。

    参数
    ----
    K : ndarray
        缩减刚度矩阵 K_FF。
    R : ndarray
        右端项 rhs = f_F - K_EF^T d_E。
    method : str
        当前支持 "ldlt" 和 "numpy_check"。
        "numpy_check" 只用于结果校核，不作为作业核心求解方法。
    """
    method = method.lower()
    if method == "ldlt":
        t0 = time.perf_counter()
        L, D = ldlt_factor(K, tol=options.get("tol", 1.0e-12))
        t1 = time.perf_counter()
        a = ldlt_solve(L, D, R)
        t2 = time.perf_counter()
        info = SolverInfo(
            method="ldlt",
            success=True,
            factor_time=t1 - t0,
            solve_time=t2 - t1,
            min_pivot=float(np.min(D)),
            message="LDL^T 分解和求解成功。",
        )
        return a, info

    if method == "numpy_check":
        # 仅用于检查结果，不用于本作业核心算法。
        t0 = time.perf_counter()
        a = np.linalg.solve(np.array(K, dtype=float), np.array(R, dtype=float))
        t1 = time.perf_counter()
        info = SolverInfo(
            method="numpy_check",
            success=True,
            factor_time=0.0,
            solve_time=t1 - t0,
            min_pivot=None,
            message="NumPy 求解仅用于结果校核。",
        )
        return a, info

    raise ValueError(f"未知求解方法：{method}")


def residual_norm(K: np.ndarray, a: np.ndarray, R: np.ndarray):
    """计算残差向量、残差范数和相对残差。"""
    A = np.array(K, dtype=float)
    x = np.array(a, dtype=float)
    b = np.array(R, dtype=float)
    r = b - A @ x
    norm_r = float(np.linalg.norm(r))
    norm_b = float(np.linalg.norm(b))
    rel = norm_r / norm_b if norm_b > 0 else norm_r
    return r, norm_r, rel


def tridiagonal_ldlt_solve(n: int, R: np.ndarray):
    """
    三对角矩阵算例的专用 LDL^T 求解器。

    矩阵为 diag=2，subdiag=superdiag=-1。
    该算法只存储主元 D 和次对角 L，时间复杂度 O(n)。
    """
    R = np.array(R, dtype=float, copy=True)
    D = np.zeros(n, dtype=float)
    ell = np.zeros(n - 1, dtype=float)

    D[0] = 2.0
    for i in range(1, n):
        ell[i - 1] = -1.0 / D[i - 1]
        D[i] = 2.0 - ell[i - 1] * ell[i - 1] * D[i - 1]
        if D[i] <= 1.0e-12:
            raise LDLTError(f"三对角矩阵出现非正主元：第 {i + 1} 个主元 = {D[i]:.6e}")

    # 前代 L y = R
    y = np.zeros(n, dtype=float)
    y[0] = R[0]
    for i in range(1, n):
        y[i] = R[i] - ell[i - 1] * y[i - 1]

    # 对角求解 D z = y
    z = y / D

    # 回代 L^T a = z
    a = np.zeros(n, dtype=float)
    a[-1] = z[-1]
    for i in range(n - 2, -1, -1):
        a[i] = z[i] - ell[i] * a[i + 1]

    return a, D, ell
