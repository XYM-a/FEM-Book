# -*- coding: utf-8 -*-
"""运行 2.4 作业的所有主要验证算例。"""

from __future__ import annotations

import csv
import json
import time
from pathlib import Path

import numpy as np

from error_analysis import analyze_ill_conditioned
from fem_model import read_model_json
from fem_postprocess import compute_element_results
from fem_solver import solve_fem_model
from formatting import matrix_to_string, vector_to_string
from ldlt_solver import LDLTError, ldlt_factor, ldlt_solve, residual_norm, tridiagonal_ldlt_solve
from sparse_poisson_q4 import solve_poisson_q4, save_poisson_figures

ROOT = Path(__file__).resolve().parent
EXAMPLES = ROOT / "examples"
OUTPUTS = ROOT / "outputs"
FIGURES = ROOT / "figures"


def write_text(path: Path, text: str):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")
    print(f"已写入：{path}")


def run_fem_case(json_name: str):
    model = read_model_json(EXAMPLES / json_name)
    result = solve_fem_model(model, method="ldlt")
    elem_results = compute_element_results(model)

    lines = []
    lines.append(f"算例标题：{model.title}")
    lines.append(f"输入文件：{EXAMPLES / json_name}")
    lines.append("")
    lines.append("对号矩阵 LM（程序内部 0 基自由度号）：")
    lines.append(str(model.LM))
    lines.append("对号矩阵 LM（报告显示 1 基自由度号）：")
    lines.append(str(model.LM + 1))
    lines.append("")
    lines.append("总体刚度矩阵 K：")
    lines.append(matrix_to_string(result["K"]))
    lines.append("")
    lines.append("缩减刚度矩阵 K_FF：")
    lines.append(matrix_to_string(result["K_FF"]))
    lines.append("右端项 rhs = f_F - K_FE d_E：")
    lines.append(vector_to_string(result["rhs"]))
    lines.append("")
    info = result["solver_info"]
    lines.append("LDL^T 求解器信息：")
    lines.append(f"成功：{info.success}")
    lines.append(f"最小主元：{info.min_pivot:.12e}")
    lines.append(f"分解时间：{info.factor_time:.6e} s")
    lines.append(f"求解时间：{info.solve_time:.6e} s")
    lines.append(f"缩减方程相对残差：{result['reduced_relative_residual']:.6e}")
    lines.append("")
    lines.append("完整节点位移 d：")
    for i, val in enumerate(model.d, start=1):
        lines.append(f"d{i} = {val:.6f}")
    lines.append("")
    lines.append("约束反力（仅列出给定位移自由度）：")
    for dof in model.fixed_dof:
        lines.append(f"r{dof + 1} = {result['reactions'][dof]:.6f}")
    lines.append("")
    lines.append("单元长度、方向余弦、应力与轴力：")
    for item in elem_results:
        lines.append(
            f"单元 {item['element']}: L = {item['length']:.6f}, "
            f"方向余弦 = {vector_to_string(item['gamma'])}, "
            f"应力 = {item['stress']:.6f}, 轴力 = {item['axial_force']:.6f}"
        )

    out_name = json_name.replace(".json", "_output.txt")
    write_text(OUTPUTS / out_name, "\n".join(lines))
    return model, result, elem_results, "\n".join(lines)


def run_tridiagonal_cases():
    ns = [10, 100, 500, 1000]
    rows = []
    lines = []
    lines.append("三对角对称正定矩阵算例")
    lines.append("K[i,i] = 2, K[i,i-1] = K[i-1,i] = -1，精确解为全 1 向量。")
    lines.append("")
    for n in ns:
        a_exact = np.ones(n)
        R = np.zeros(n)
        R[0] = 1.0
        R[-1] = 1.0
        # 因为 K @ ones = [1, 0, ..., 0, 1]
        t0 = time.perf_counter()
        a, D, ell = tridiagonal_ldlt_solve(n, R)
        t1 = time.perf_counter()
        rel_error = float(np.linalg.norm(a - a_exact) / np.linalg.norm(a_exact))
        # 显式构造小规模/稀疏验证残差时只做三对角乘法
        Ka = np.empty(n)
        Ka[0] = 2 * a[0] - a[1]
        for i in range(1, n - 1):
            Ka[i] = -a[i - 1] + 2 * a[i] - a[i + 1]
        Ka[-1] = -a[-2] + 2 * a[-1]
        rel_res = float(np.linalg.norm(R - Ka) / np.linalg.norm(R))
        dense_mem_mb = n * n * 8.0 / 1024.0**2
        sparse_mem_mb = ((3 * n - 2) * (8 + 4) + (n + 1) * 4) / 1024.0**2
        rows.append([n, t1 - t0, rel_error, rel_res, dense_mem_mb, sparse_mem_mb, np.min(D)])
        lines.append(
            f"n={n:4d}: 求解时间={t1-t0:.6e} s, 相对误差={rel_error:.6e}, "
            f"相对残差={rel_res:.6e}, 稠密内存约={dense_mem_mb:.3f} MB, "
            f"三对角/CSR近似内存约={sparse_mem_mb:.3f} MB"
        )

    csv_path = OUTPUTS / "tridiagonal_timing.csv"
    csv_path.parent.mkdir(parents=True, exist_ok=True)
    with open(csv_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["n", "solve_time_s", "relative_error", "relative_residual", "dense_memory_MB", "sparse_memory_MB", "min_pivot"])
        writer.writerows(rows)
    write_text(OUTPUTS / "tridiagonal_output.txt", "\n".join(lines))
    return rows, "\n".join(lines)


def run_indefinite_case():
    with open(EXAMPLES / "indefinite_matrix.json", "r", encoding="utf-8") as f:
        data = json.load(f)
    K = np.array(data["K"], dtype=float)
    R = np.array(data["R"], dtype=float)
    lines = []
    lines.append(data["Title"])
    lines.append("矩阵 K：")
    lines.append(matrix_to_string(K))
    lines.append("右端项 R：")
    lines.append(vector_to_string(R))
    try:
        L, D = ldlt_factor(K)
        a = ldlt_solve(L, D, R)
        lines.append("未检测到错误，解为：")
        lines.append(vector_to_string(a))
    except LDLTError as exc:
        lines.append("LDL^T 分解停止。")
        lines.append(f"错误提示：{exc}")
        lines.append("说明：该矩阵特征值为 3 和 -1，不是正定矩阵。")
    write_text(OUTPUTS / "nonpositive_pivot_output.txt", "\n".join(lines))
    return "\n".join(lines)


def run_error_analysis():
    K, R, a_exact, cond, rows = analyze_ill_conditioned()
    lines = []
    lines.append("病态矩阵误差分析算例")
    lines.append("矩阵 K：")
    lines.append(matrix_to_string(K, digits=8))
    lines.append(f"精确解：{vector_to_string(a_exact)}")
    lines.append(f"右端项 R = K a_exact：{vector_to_string(R, digits=8)}")
    lines.append(f"条件数 cond(K) = {cond:.6e}")
    lines.append("")
    for row in rows:
        lines.append(f"情况：{row['case']}")
        lines.append(f"数值解 a = {vector_to_string(row['a'], digits=8)}")
        lines.append(f"残差 r = {vector_to_string(row['residual'], digits=8)}")
        lines.append(f"相对残差 = {row['relative_residual']:.6e}")
        lines.append(f"相对误差 = {row['relative_error']:.6e}")
        lines.append("")

    write_text(OUTPUTS / "ill_conditioned_output.txt", "\n".join(lines))
    return rows, "\n".join(lines)


def run_multi_load_case():
    n = 200
    # 使用三对角 SPD 矩阵演示同一个 K、多个 RHS：R 的三列对应三种已知解。
    xs = [np.ones(n), np.linspace(0, 1, n), np.sin(np.linspace(0, np.pi, n))]
    # 显式构造小矩阵用于 dense LDLT，多载荷规模 n=200 可接受。
    K = np.diag(2.0 * np.ones(n)) + np.diag(-1.0 * np.ones(n - 1), 1) + np.diag(-1.0 * np.ones(n - 1), -1)
    R = np.column_stack([K @ x for x in xs])

    t0 = time.perf_counter()
    L, D = ldlt_factor(K)
    factor_once_time = time.perf_counter() - t0
    t1 = time.perf_counter()
    A = ldlt_solve(L, D, R)
    solve_multi_time = time.perf_counter() - t1

    t2 = time.perf_counter()
    A2 = []
    for col in range(R.shape[1]):
        Lc, Dc = ldlt_factor(K)
        A2.append(ldlt_solve(Lc, Dc, R[:, col]))
    repeat_time = time.perf_counter() - t2

    errors = [float(np.linalg.norm(A[:, i] - xs[i]) / np.linalg.norm(xs[i])) for i in range(3)]
    lines = []
    lines.append("多载荷工况效率比较")
    lines.append(f"矩阵阶数 n = {n}，右端项个数 = 3")
    lines.append(f"先分解一次 K 的时间 = {factor_once_time:.6e} s")
    lines.append(f"对三个右端项前代/对角求解/回代总时间 = {solve_multi_time:.6e} s")
    lines.append(f"每个右端项都重新分解的总时间 = {repeat_time:.6e} s")
    lines.append(f"三个右端项相对误差 = {[f'{e:.3e}' for e in errors]}")
    write_text(OUTPUTS / "multi_load_output.txt", "\n".join(lines))
    return "\n".join(lines)


def run_poisson_cases():
    sizes = [50, 100, 200]
    rows = []
    lines = []
    lines.append("二维 Poisson 方程 Q4 有限元稀疏求解算例")
    for n in sizes:
        result = solve_poisson_q4(nx=n, ny=n, prefer_pardiso=True)
        rows.append([
            result.nx,
            result.ny,
            result.solver_name,
            result.n_nodes,
            result.n_elements,
            result.n_unknowns,
            result.nnz,
            result.assembly_time,
            result.bc_time,
            result.solve_time,
            result.total_time,
            result.relative_residual,
            result.max_error,
            result.relative_l2_error,
            result.memory_mb,
        ])
        lines.append(
            f"nx=ny={n}: 求解器={result.solver_name}, 节点数={result.n_nodes}, 单元数={result.n_elements}, "
            f"未知数={result.n_unknowns}, nnz={result.nnz}, 装配={result.assembly_time:.3f}s, "
            f"求解={result.solve_time:.3f}s, 相对残差={result.relative_residual:.3e}, "
            f"最大误差={result.max_error:.3e}, L2相对误差={result.relative_l2_error:.3e}"
        )
        if n == 50:
            save_poisson_figures(result, FIGURES)

    csv_path = OUTPUTS / "poisson_summary.csv"
    csv_path.parent.mkdir(parents=True, exist_ok=True)
    with open(csv_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow([
            "nx", "ny", "solver", "nodes", "elements", "unknowns", "nnz", "assembly_time_s",
            "bc_time_s", "solve_time_s", "total_time_s", "relative_residual", "max_error", "relative_L2_error", "csr_memory_MB"
        ])
        writer.writerows(rows)
    write_text(OUTPUTS / "poisson_output.txt", "\n".join(lines))
    return rows, "\n".join(lines)


def main():
    OUTPUTS.mkdir(exist_ok=True)
    FIGURES.mkdir(exist_ok=True)

    all_lines = []
    for json_name in ["rod_1d.json", "truss_2d.json"]:
        _, _, _, text = run_fem_case(json_name)
        all_lines.append(text)
        all_lines.append("\n" + "=" * 80 + "\n")

    _, tri_text = run_tridiagonal_cases()
    all_lines.append(tri_text)
    all_lines.append("\n" + "=" * 80 + "\n")

    all_lines.append(run_indefinite_case())
    all_lines.append("\n" + "=" * 80 + "\n")

    _, err_text = run_error_analysis()
    all_lines.append(err_text)
    all_lines.append("\n" + "=" * 80 + "\n")

    all_lines.append(run_multi_load_case())
    all_lines.append("\n" + "=" * 80 + "\n")

    _, poisson_text = run_poisson_cases()
    all_lines.append(poisson_text)

    write_text(OUTPUTS / "run_all_output.txt", "\n".join(all_lines))
    print("全部算例运行完成。")


if __name__ == "__main__":
    main()
