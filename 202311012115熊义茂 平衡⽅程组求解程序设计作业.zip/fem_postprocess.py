# -*- coding: utf-8 -*-
"""单元应力和轴力后处理模块。"""

from __future__ import annotations

import numpy as np

from fem_element import element_geometry
from fem_model import FEMModel


def compute_element_results(model: FEMModel):
    """计算各单元长度、方向余弦、应力和轴力。"""
    results = []
    for e in range(model.nel):
        L, gamma = element_geometry(model, e)
        de = model.d[model.LM[:, e]]
        if model.ndof == 1:
            B = np.array([-1.0, 1.0]) / L
        else:
            B = np.concatenate([-gamma, gamma]) / L
        stress = float(model.E[e] * (B @ de))
        axial_force = float(model.A[e] * stress)
        results.append(
            {
                "element": e + 1,
                "length": L,
                "gamma": gamma,
                "stress": stress,
                "axial_force": axial_force,
                "de": de,
            }
        )
    return results
