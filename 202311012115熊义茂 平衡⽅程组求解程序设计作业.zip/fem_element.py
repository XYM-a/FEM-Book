# -*- coding: utf-8 -*-
"""杆/桁架单元刚度矩阵与几何量计算模块。"""

from __future__ import annotations

import numpy as np

from fem_model import FEMModel


def element_geometry(model: FEMModel, e: int):
    """计算单元长度和方向余弦。"""
    nodes = model.IEN[e] - 1
    x1 = model.coords[nodes[0]]
    x2 = model.coords[nodes[1]]
    vector = x2 - x1
    L = float(np.linalg.norm(vector))
    if L <= 0.0:
        raise ValueError(f"单元 {e + 1} 长度为零。")
    gamma = vector / L
    return L, gamma


def element_stiffness(model: FEMModel, e: int):
    """
    计算一维杆或二维/三维桁架单元刚度矩阵。

    对 ndof = 1：Ke = EA/L [[1,-1],[-1,1]]
    对 ndof = 2 或 3：使用方向余弦外积统一构造。
    """
    L, gamma = element_geometry(model, e)
    const = model.E[e] * model.A[e] / L

    if model.ndof == 1:
        ke = const * np.array([[1.0, -1.0], [-1.0, 1.0]])
    else:
        gg = np.outer(gamma, gamma)
        ke = const * np.block([[gg, -gg], [-gg, gg]])
    return ke, L, gamma
