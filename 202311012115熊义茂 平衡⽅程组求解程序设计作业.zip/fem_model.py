# -*- coding: utf-8 -*-
"""有限元模型输入、自由度编号和对号矩阵生成模块。"""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import List

import numpy as np


@dataclass
class FEMModel:
    title: str
    nsd: int
    ndof: int
    nnp: int
    nel: int
    nen: int
    E: np.ndarray
    A: np.ndarray
    coords: np.ndarray
    IEN: np.ndarray
    fixed_dof: np.ndarray
    fixed_value: np.ndarray
    force_dof: np.ndarray
    force_value: np.ndarray
    neq: int
    LM: np.ndarray
    K: np.ndarray
    f: np.ndarray
    d: np.ndarray


def read_model_json(filename: str | Path) -> FEMModel:
    """从 JSON 文件读取有限元模型，并生成 LM、载荷向量和初始位移向量。"""
    filename = Path(filename)
    with open(filename, "r", encoding="utf-8") as f:
        data = json.load(f)

    title = data.get("Title", filename.stem)
    nsd = int(data["nsd"])
    ndof = int(data["ndof"])
    nnp = int(data["nnp"])
    nel = int(data["nel"])
    nen = int(data.get("nen", 2))

    E = np.array(data["E"], dtype=float)
    A = np.array(data["CArea"], dtype=float)

    coords = build_coordinates(data, nsd, nnp)
    IEN = np.array(data["IEN"], dtype=int)

    fixed_dof = np.array(data.get("fixed_dof", []), dtype=int) - 1
    fixed_value = np.array(data.get("fixed_value", []), dtype=float)
    force_dof = np.array(data.get("force_dof", []), dtype=int) - 1
    force_value = np.array(data.get("force_value", []), dtype=float)

    neq = ndof * nnp
    LM = build_location_matrix(IEN, ndof, nen)
    K = np.zeros((neq, neq), dtype=float)
    f = np.zeros(neq, dtype=float)
    d = np.zeros(neq, dtype=float)

    for dof, val in zip(force_dof, force_value):
        f[dof] += val
    for dof, val in zip(fixed_dof, fixed_value):
        d[dof] = val

    return FEMModel(
        title=title,
        nsd=nsd,
        ndof=ndof,
        nnp=nnp,
        nel=nel,
        nen=nen,
        E=E,
        A=A,
        coords=coords,
        IEN=IEN,
        fixed_dof=fixed_dof,
        fixed_value=fixed_value,
        force_dof=force_dof,
        force_value=force_value,
        neq=neq,
        LM=LM,
        K=K,
        f=f,
        d=d,
    )


def build_coordinates(data: dict, nsd: int, nnp: int) -> np.ndarray:
    """根据 x、y、z 字段构造节点坐标数组。"""
    cols: List[np.ndarray] = []
    for key in ["x", "y", "z"][:nsd]:
        if key in data:
            arr = np.array(data[key], dtype=float)
        else:
            arr = np.zeros(nnp, dtype=float)
        cols.append(arr)
    return np.vstack(cols).T


def build_location_matrix(IEN: np.ndarray, ndof: int, nen: int) -> np.ndarray:
    """
    生成对号矩阵 LM。

    输入 IEN 使用 1 基节点号；程序内部 LM 使用 0 基自由度号。
    """
    nel = IEN.shape[0]
    LM = np.zeros((nen * ndof, nel), dtype=int)
    for e in range(nel):
        for j in range(nen):
            node = IEN[e, j]
            for m in range(ndof):
                local = j * ndof + m
                global_dof = ndof * (node - 1) + m
                LM[local, e] = global_dof
    return LM


def free_dofs(model: FEMModel) -> np.ndarray:
    """返回未知位移自由度编号。"""
    all_dof = np.arange(model.neq)
    return np.setdiff1d(all_dof, model.fixed_dof)
