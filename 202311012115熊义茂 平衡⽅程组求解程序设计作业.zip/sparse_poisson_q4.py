# -*- coding: utf-8 -*-
"""二维 Poisson 方程 Q4 有限元稀疏求解示例。"""

from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Tuple

import numpy as np
from scipy.sparse import coo_matrix, csr_matrix
from scipy.sparse.linalg import spsolve


@dataclass
class PoissonResult:
    nx: int
    ny: int
    solver_name: str
    n_nodes: int
    n_elements: int
    n_unknowns: int
    nnz: int
    assembly_time: float
    bc_time: float
    solve_time: float
    total_time: float
    relative_residual: float
    max_error: float
    relative_l2_error: float
    memory_mb: float
    x: np.ndarray
    y: np.ndarray
    u: np.ndarray
    u_exact: np.ndarray


def exact_u(x, y):
    return np.sin(np.pi * x) * np.sin(np.pi * y)


def rhs_f(x, y):
    return 2.0 * np.pi**2 * np.sin(np.pi * x) * np.sin(np.pi * y)


def q4_shape(xi, eta):
    N = 0.25 * np.array(
        [
            (1 - xi) * (1 - eta),
            (1 + xi) * (1 - eta),
            (1 + xi) * (1 + eta),
            (1 - xi) * (1 + eta),
        ]
    )
    dN_dxi = 0.25 * np.array(
        [
            [-(1 - eta), -(1 - xi)],
            [+(1 - eta), -(1 + xi)],
            [+(1 + eta), +(1 + xi)],
            [-(1 + eta), +(1 - xi)],
        ]
    )
    return N, dN_dxi


def element_q4_matrices(coords):
    """计算一个 Q4 单元刚度矩阵和载荷列阵。"""
    ke = np.zeros((4, 4), dtype=float)
    fe = np.zeros(4, dtype=float)
    gp = [-1.0 / np.sqrt(3.0), 1.0 / np.sqrt(3.0)]
    for xi in gp:
        for eta in gp:
            N, dN_ref = q4_shape(xi, eta)
            J = dN_ref.T @ coords
            detJ = float(np.linalg.det(J))
            invJ = np.linalg.inv(J)
            dN_xy = dN_ref @ invJ
            ke += (dN_xy @ dN_xy.T) * detJ
            xg, yg = N @ coords
            fe += N * rhs_f(xg, yg) * detJ
    return ke, fe


def solve_poisson_q4(nx=50, ny=50, prefer_pardiso=True) -> PoissonResult:
    """
    使用 Q4 有限元求解单位正方形 Poisson 方程。

    程序优先尝试 pypardiso/MKL PARDISO；如果未安装，则使用 SciPy 的 SuperLU 稀疏直接求解器。
    """
    t_all = time.perf_counter()

    xs = np.linspace(0.0, 1.0, nx + 1)
    ys = np.linspace(0.0, 1.0, ny + 1)
    X, Y = np.meshgrid(xs, ys, indexing="xy")
    x = X.ravel()
    y = Y.ravel()
    n_nodes = (nx + 1) * (ny + 1)
    n_elements = nx * ny

    rows = []
    cols = []
    vals = []
    F = np.zeros(n_nodes, dtype=float)

    t0 = time.perf_counter()
    for ey in range(ny):
        for ex in range(nx):
            n0 = ey * (nx + 1) + ex
            conn = np.array([n0, n0 + 1, n0 + nx + 2, n0 + nx + 1], dtype=int)
            coords = np.column_stack([x[conn], y[conn]])
            ke, fe = element_q4_matrices(coords)
            for a in range(4):
                F[conn[a]] += fe[a]
                for b in range(4):
                    rows.append(conn[a])
                    cols.append(conn[b])
                    vals.append(ke[a, b])
    K = coo_matrix((vals, (rows, cols)), shape=(n_nodes, n_nodes)).tocsr()
    assembly_time = time.perf_counter() - t0

    t1 = time.perf_counter()
    boundary = (np.isclose(x, 0.0) | np.isclose(x, 1.0) | np.isclose(y, 0.0) | np.isclose(y, 1.0))
    free = np.where(~boundary)[0]
    K_FF = K[free][:, free].tocsr()
    F_F = F[free]
    bc_time = time.perf_counter() - t1

    solver_name = "SciPy/SuperLU"
    t2 = time.perf_counter()
    if prefer_pardiso:
        try:
            from pypardiso import spsolve as pardiso_spsolve  # type: ignore

            u_F = pardiso_spsolve(K_FF, F_F)
            solver_name = "pypardiso / MKL PARDISO"
        except Exception:
            u_F = spsolve(K_FF, F_F)
            solver_name = "SciPy/SuperLU（未检测到 pypardiso/MKL PARDISO）"
    else:
        u_F = spsolve(K_FF, F_F)
    solve_time = time.perf_counter() - t2

    u = np.zeros(n_nodes, dtype=float)
    u[free] = u_F
    ue = exact_u(x, y)

    residual = F_F - K_FF @ u_F
    relative_residual = float(np.linalg.norm(residual) / np.linalg.norm(F_F))
    err = u - ue
    max_error = float(np.max(np.abs(err)))
    relative_l2_error = float(np.sqrt(np.sum(err**2) / np.sum(ue**2)))
    memory_mb = float((K_FF.data.nbytes + K_FF.indices.nbytes + K_FF.indptr.nbytes) / 1024.0**2)
    total_time = time.perf_counter() - t_all

    return PoissonResult(
        nx=nx,
        ny=ny,
        solver_name=solver_name,
        n_nodes=n_nodes,
        n_elements=n_elements,
        n_unknowns=len(free),
        nnz=K_FF.nnz,
        assembly_time=assembly_time,
        bc_time=bc_time,
        solve_time=solve_time,
        total_time=total_time,
        relative_residual=relative_residual,
        max_error=max_error,
        relative_l2_error=relative_l2_error,
        memory_mb=memory_mb,
        x=x,
        y=y,
        u=u,
        u_exact=ue,
    )


def save_poisson_figures(result: PoissonResult, out_dir):
    """保存数值解云图和误差云图。"""
    import matplotlib.pyplot as plt
    from pathlib import Path

    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    nx, ny = result.nx, result.ny
    X = result.x.reshape(ny + 1, nx + 1)
    Y = result.y.reshape(ny + 1, nx + 1)
    U = result.u.reshape(ny + 1, nx + 1)
    Err = (result.u - result.u_exact).reshape(ny + 1, nx + 1)

    plt.figure(figsize=(6, 5))
    cp = plt.contourf(X, Y, U, levels=20)
    plt.colorbar(cp)
    plt.title(f"Poisson Q4 numerical solution, nx=ny={nx}")
    plt.xlabel("x")
    plt.ylabel("y")
    plt.tight_layout()
    sol_path = out_dir / "poisson_solution.png"
    plt.savefig(sol_path, dpi=160)
    plt.close()

    plt.figure(figsize=(6, 5))
    cp = plt.contourf(X, Y, Err, levels=20)
    plt.colorbar(cp)
    plt.title(f"Poisson Q4 nodal error, nx=ny={nx}")
    plt.xlabel("x")
    plt.ylabel("y")
    plt.tight_layout()
    err_path = out_dir / "poisson_error.png"
    plt.savefig(err_path, dpi=160)
    plt.close()

    return sol_path, err_path
