import numpy as np
import matplotlib.pyplot as plt


# ============================================================
# 1. 精确解与 SUPG 参数
# ============================================================

def exact_solution(x, length, velocity, diffusion):
    """
    计算精确解。

    为避免高 Pe 情况下指数溢出，这里对指数较大的情况
    使用等价变形公式。
    """

    beta = velocity / diffusion

    if beta * length < 700:
        return np.expm1(beta * x) / np.expm1(beta * length)

    numerator = np.exp(beta * (x - length)) * (1.0 - np.exp(-beta * x))
    denominator = 1.0 - np.exp(-beta * length)

    return numerator / denominator


def supg_alpha(peclet):
    """
    SUPG 稳定化参数：

        alpha = coth(Pe) - 1 / Pe

    Pe 很小时使用 alpha ≈ Pe/3，避免数值相消。
    """

    if abs(peclet) < 1.0e-10:
        return peclet / 3.0

    return 1.0 / np.tanh(peclet) - 1.0 / peclet


# ============================================================
# 2. 单元矩阵
# ============================================================

def effective_diffusion(diffusion, velocity, element_length, alpha):
    """
    加入人工扩散后的等效扩散系数：

        kappa_eff = kappa + alpha * v * le / 2
    """

    return diffusion + alpha * velocity * element_length / 2.0


def element_matrix(diffusion, velocity, element_length, alpha):
    """
    两节点线性单元矩阵。

    标准 Galerkin：
        alpha = 0

    迎风格式：
        alpha = 1

    SUPG：
        alpha = coth(Pe) - 1/Pe
    """

    diffusion_eff = effective_diffusion(
        diffusion,
        velocity,
        element_length,
        alpha
    )

    diffusion_part = diffusion_eff / element_length * np.array([
        [1.0, -1.0],
        [-1.0, 1.0]
    ])

    advection_part = velocity / 2.0 * np.array([
        [-1.0, 1.0],
        [-1.0, 1.0]
    ])

    return diffusion_part + advection_part


# ============================================================
# 3. 总体矩阵组装与求解
# ============================================================

def assemble_system(element_count, length, velocity, diffusion, alpha_setting):
    """
    组装总体矩阵。

    alpha_setting 可以是：
        0.0        标准 Galerkin
        1.0        迎风格式
        supg_alpha SUPG 稳定化方法
    """

    node_count = element_count + 1
    element_length = length / element_count

    x = np.linspace(0.0, length, node_count)

    peclet = velocity * element_length / (2.0 * diffusion)

    if callable(alpha_setting):
        alpha_value = alpha_setting(peclet)
    else:
        alpha_value = float(alpha_setting)

    K = np.zeros((node_count, node_count), dtype=float)
    F = np.zeros(node_count, dtype=float)

    for e in range(element_count):
        left_node = e
        right_node = e + 1
        local_nodes = [left_node, right_node]

        Ke = element_matrix(
            diffusion,
            velocity,
            element_length,
            alpha_value
        )

        for i_local in range(2):
            i_global = local_nodes[i_local]

            for j_local in range(2):
                j_global = local_nodes[j_local]
                K[i_global, j_global] += Ke[i_local, j_local]

    K_raw = K.copy()

    return x, K, F, K_raw, peclet, alpha_value


def apply_boundary_conditions(K, F, left_value=0.0, right_value=1.0):
    """
    施加 Dirichlet 边界条件：

        u(0) = left_value
        u(L) = right_value
    """

    K_bc = K.copy()
    F_bc = F.copy()

    # 左端边界
    K_bc[0, :] = 0.0
    K_bc[0, 0] = 1.0
    F_bc[0] = left_value

    # 右端边界
    K_bc[-1, :] = 0.0
    K_bc[-1, -1] = 1.0
    F_bc[-1] = right_value

    return K_bc, F_bc


def solve_method(element_count, length, velocity, diffusion, alpha_setting):
    """
    求解一种方法。
    """

    x, K, F, K_raw, peclet, alpha_value = assemble_system(
        element_count,
        length,
        velocity,
        diffusion,
        alpha_setting
    )

    K_bc, F_bc = apply_boundary_conditions(
        K,
        F,
        left_value=0.0,
        right_value=1.0
    )

    numerical = np.linalg.solve(K_bc, F_bc)

    exact = exact_solution(
        x,
        length,
        velocity,
        diffusion
    )

    return {
        "x": x,
        "numerical": numerical,
        "exact": exact,
        "K_bc": K_bc,
        "K_raw": K_raw,
        "peclet": peclet,
        "alpha": alpha_value
    }


# ============================================================
# 4. 误差与矩阵性质
# ============================================================

def compute_error(numerical, exact):
    """
    计算最大节点误差和相对 L2 误差。
    """

    error = numerical - exact

    max_error = np.max(np.abs(error))

    denominator = np.sqrt(np.sum(exact ** 2))

    if denominator < 1.0e-14:
        relative_l2_error = np.nan
    else:
        relative_l2_error = np.sqrt(np.sum(error ** 2)) / denominator

    return max_error, relative_l2_error


def analyze_matrix(K_raw):
    """
    分析未施加边界条件时内部节点矩阵的性质。
    """

    K_inner = K_raw[1:-1, 1:-1]

    symmetry_error = np.linalg.norm(K_inner - K_inner.T)
    matrix_norm = np.linalg.norm(K_inner)

    if matrix_norm < 1.0e-14:
        asymmetry_ratio = np.nan
    else:
        asymmetry_ratio = symmetry_error / matrix_norm

    eigenvalues = np.linalg.eigvals(K_inner)

    min_real_eigenvalue = np.min(np.real(eigenvalues))

    is_symmetric = np.allclose(K_inner, K_inner.T)
    all_real_parts_positive = np.all(np.real(eigenvalues) > 0.0)

    condition_number = np.linalg.cond(K_inner)

    return {
        "is_symmetric": is_symmetric,
        "all_real_parts_positive": all_real_parts_positive,
        "min_real_eigenvalue": min_real_eigenvalue,
        "asymmetry_ratio": asymmetry_ratio,
        "condition_number": condition_number
    }


# ============================================================
# 5. 算例运行与输出
# ============================================================

def run_case(target_peclet, element_count=20, length=1.0, velocity=1.0):
    """
    运行一个指定 Peclet 数的算例。

    由目标 Peclet 数反推扩散系数：

        kappa = v * le / (2 * Pe)
    """

    element_length = length / element_count
    diffusion = velocity * element_length / (2.0 * target_peclet)

    methods = {
        "Galerkin": 0.0,
        "Upwind": 1.0,
        "SUPG": supg_alpha
    }

    results = {}

    print()
    print("=" * 92)
    print(f"算例：Pe = {target_peclet}")
    print("=" * 92)
    print(f"区域长度 L        = {length}")
    print(f"单元数 nel        = {element_count}")
    print(f"节点数 nnode      = {element_count + 1}")
    print(f"单元长度 le       = {element_length:.6f}")
    print(f"对流速度 v        = {velocity:.6f}")
    print(f"扩散系数 kappa    = {diffusion:.6f}")

    for method_name, alpha_setting in methods.items():
        data = solve_method(
            element_count,
            length,
            velocity,
            diffusion,
            alpha_setting
        )

        max_error, l2_error = compute_error(
            data["numerical"],
            data["exact"]
        )

        data["max_error"] = max_error
        data["l2_error"] = l2_error
        data["diffusion"] = diffusion
        data["element_length"] = element_length
        data["element_count"] = element_count
        data["length"] = length
        data["velocity"] = velocity

        results[method_name] = data

    print()
    print("三种方法误差：")
    print("-" * 92)
    print(f"{'方法':<15}{'alpha':>15}{'最大误差':>20}{'相对L2误差':>20}")
    print("-" * 92)

    for method_name in ["Galerkin", "Upwind", "SUPG"]:
        item = results[method_name]
        print(
            f"{method_name:<15}"
            f"{item['alpha']:>15.6f}"
            f"{item['max_error']:>20.6e}"
            f"{item['l2_error']:>20.6e}"
        )

    return results


def print_node_comparison(results, sample_locations):
    """
    输出部分节点解对比。
    """

    x = results["Galerkin"]["x"]
    exact = results["Galerkin"]["exact"]

    print()
    print("部分节点解对比：")
    print("-" * 108)
    print(
        f"{'x':>10}"
        f"{'精确解':>18}"
        f"{'Galerkin':>18}"
        f"{'Upwind':>18}"
        f"{'SUPG':>18}"
    )
    print("-" * 108)

    for location in sample_locations:
        node_id = int(np.argmin(np.abs(x - location)))

        print(
            f"{x[node_id]:>10.2f}"
            f"{exact[node_id]:>18.6f}"
            f"{results['Galerkin']['numerical'][node_id]:>18.6f}"
            f"{results['Upwind']['numerical'][node_id]:>18.6f}"
            f"{results['SUPG']['numerical'][node_id]:>18.6f}"
        )


def print_error_summary(results_pe_01, results_pe_30):
    """
    输出两种 Pe 数下的误差总表。
    """

    print()
    print("=" * 92)
    print("误差总表")
    print("=" * 92)
    print(
        f"{'方法':<15}"
        f"{'Pe=0.1 最大误差':>24}"
        f"{'Pe=3.0 最大误差':>24}"
    )
    print("-" * 92)

    for method_name in ["Galerkin", "Upwind", "SUPG"]:
        print(
            f"{method_name:<15}"
            f"{results_pe_01[method_name]['max_error']:>24.6e}"
            f"{results_pe_30[method_name]['max_error']:>24.6e}"
        )


def print_matrix_analysis(results_pe_30):
    """
    输出 Pe = 3.0 时标准 Galerkin 矩阵性质分析。
    """

    matrix_info = analyze_matrix(results_pe_30["Galerkin"]["K_raw"])

    print()
    print("=" * 92)
    print("矩阵性质分析：Pe = 3.0，标准 Galerkin，内部节点矩阵")
    print("=" * 92)
    print(f"是否对称                         : {matrix_info['is_symmetric']}")
    print(f"是否所有特征值实部为正             : {matrix_info['all_real_parts_positive']}")
    print(f"最小特征值实部                   : {matrix_info['min_real_eigenvalue']:.6e}")
    print(f"非对称程度 ||K-K^T|| / ||K||      : {matrix_info['asymmetry_ratio']:.6e}")
    print(f"条件数 cond(K)                   : {matrix_info['condition_number']:.6e}")

    print()
    print("简要说明：")
    print("1. 扩散项形成的矩阵是对称的，对流项形成的矩阵是非对称的。")
    print("2. Pe 较大时，对流项影响增强，标准 Galerkin 方法容易出现数值振荡。")
    print("3. 迎风格式通过增加人工扩散抑制振荡，但会带来数值耗散。")
    print("4. SUPG 方法在稳定性和精度之间取得较好平衡。")


# ============================================================
# 6. 绘图
# ============================================================

def plot_solution_comparison(results, peclet_value, filename):
    """
    绘制三种方法与精确解对比图。

    图片标题使用英文，避免 Matplotlib 中文字体 warning。
    """

    x = results["Galerkin"]["x"]
    exact = results["Galerkin"]["exact"]

    plt.figure(figsize=(8, 5))

    plt.plot(
        x,
        exact,
        "k-",
        linewidth=2.0,
        label="Exact solution"
    )

    plt.plot(
        x,
        results["Galerkin"]["numerical"],
        "o-",
        markersize=4,
        label=f"Galerkin, err={results['Galerkin']['max_error']:.4f}"
    )

    plt.plot(
        x,
        results["Upwind"]["numerical"],
        "s-",
        markersize=4,
        label=f"Upwind, err={results['Upwind']['max_error']:.4f}"
    )

    plt.plot(
        x,
        results["SUPG"]["numerical"],
        "^-",
        markersize=4,
        label=f"SUPG, err={results['SUPG']['max_error']:.4f}"
    )

    plt.xlabel("x")
    plt.ylabel("u")
    plt.title(f"Advection-Diffusion FEM Comparison, Pe = {peclet_value}")
    plt.grid(True, alpha=0.3)
    plt.legend()
    plt.tight_layout()
    plt.savefig(filename, dpi=300)
    plt.close()


def plot_error_comparison(results_pe_01, results_pe_30, filename):
    """
    绘制两种 Pe 数下三种方法的最大误差对比。
    """

    methods = ["Galerkin", "Upwind", "SUPG"]

    error_pe_01 = [
        results_pe_01[method]["max_error"] for method in methods
    ]

    error_pe_30 = [
        results_pe_30[method]["max_error"] for method in methods
    ]

    x_locations = np.arange(len(methods))
    width = 0.35

    plt.figure(figsize=(8, 5))

    plt.bar(
        x_locations - width / 2.0,
        error_pe_01,
        width,
        label="Pe = 0.1"
    )

    plt.bar(
        x_locations + width / 2.0,
        error_pe_30,
        width,
        label="Pe = 3.0"
    )

    plt.xticks(x_locations, methods)
    plt.yscale("log")
    plt.ylabel("Maximum nodal error")
    plt.title("Maximum Error Comparison")
    plt.grid(True, axis="y", alpha=0.3)
    plt.legend()
    plt.tight_layout()
    plt.savefig(filename, dpi=300)
    plt.close()


# ============================================================
# 7. 主程序
# ============================================================

def main():
    print("一维稳态对流扩散方程有限元求解与稳定化")
    print("=" * 92)
    print("控制方程：-kappa * d²u/dx² + v * du/dx = 0")
    print("边界条件：u(0) = 0, u(L) = 1")
    print("比较方法：标准 Galerkin、迎风格式、SUPG")
    print("计算目标：比较扩散占优和对流占优时的稳定性")
    print("=" * 92)

    # Pe = 0.1，扩散占优
    results_pe_01 = run_case(
        target_peclet=0.1,
        element_count=20,
        length=1.0,
        velocity=1.0
    )

    print_node_comparison(
        results_pe_01,
        sample_locations=[0.00, 0.25, 0.50, 0.75, 1.00]
    )

    # Pe = 3.0，对流占优
    results_pe_30 = run_case(
        target_peclet=3.0,
        element_count=20,
        length=1.0,
        velocity=1.0
    )

    print_node_comparison(
        results_pe_30,
        sample_locations=[0.00, 0.70, 0.80, 0.90, 0.95, 1.00]
    )

    # 误差总表
    print_error_summary(results_pe_01, results_pe_30)

    # 矩阵性质分析
    print_matrix_analysis(results_pe_30)

    # 绘制图片
    plot_solution_comparison(
        results_pe_01,
        peclet_value=0.1,
        filename="result_solution_pe_0_1.png"
    )

    plot_solution_comparison(
        results_pe_30,
        peclet_value=3.0,
        filename="result_solution_pe_3_0.png"
    )

    plot_error_comparison(
        results_pe_01,
        results_pe_30,
        filename="result_error_comparison.png"
    )

    print()
    print("=" * 92)
    print("计算完成。")
    print("已生成图片文件：")
    print("1. result_solution_pe_0_1.png")
    print("2. result_solution_pe_3_0.png")
    print("3. result_error_comparison.png")
    print("=" * 92)


if __name__ == "__main__":
    main()