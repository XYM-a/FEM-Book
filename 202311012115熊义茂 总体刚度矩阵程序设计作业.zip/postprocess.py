"""单元应力和轴力后处理。"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from model import FEMModel
from element import element_info


@dataclass
class ElementResult:
    """保存一个单元的长度、方向余弦、应力和轴力。"""

    element: int
    length: float
    direction_cosines: np.ndarray
    stress: float
    axial_force: float


def compute_element_results(model: FEMModel) -> list[ElementResult]:
    """根据总体位移列阵提取单元位移，并计算各单元应力和轴力。"""
    results: list[ElementResult] = []
    for e in range(model.nel):
        info = element_info(model, e)
        # de 为该单元的节点位移列阵，由总体位移 d 按 LM 提取。
        de = model.d[model.LM[:, e]]

        if model.ndof == 1:
            B = np.array([-1.0, 1.0])
        else:
            gamma = info.direction_cosines
            B = np.concatenate((-gamma, gamma))

        stress = float(model.E[e] / info.length * (B @ de))
        axial_force = float(model.area[e] * stress)
        results.append(
            ElementResult(
                element=e + 1,
                length=info.length,
                direction_cosines=info.direction_cosines,
                stress=stress,
                axial_force=axial_force,
            )
        )
    return results
