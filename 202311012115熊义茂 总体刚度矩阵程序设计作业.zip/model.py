"""有限元模型数据读取、自由度编号和 LM 对号矩阵生成。"""
from __future__ import annotations

from dataclasses import dataclass, field
import json
from pathlib import Path
from typing import Any

import numpy as np


@dataclass
class FEMModel:
    """杆/桁架有限元模型的数据容器。"""

    title: str
    nsd: int
    ndof: int
    nnp: int
    nel: int
    nen: int
    E: np.ndarray
    area: np.ndarray
    coords: np.ndarray
    IEN: np.ndarray  # 1 基节点号，形状为 (nel, nen)
    fixed_dof: np.ndarray  # 1 基已知位移自由度号
    fixed_value: np.ndarray
    force_dof: np.ndarray  # 1 基受力自由度号
    force_value: np.ndarray
    neq: int = field(init=False)
    LM: np.ndarray = field(init=False)  # 0 基总体自由度号，形状为 (nen*ndof, nel)
    K: np.ndarray = field(init=False)
    f: np.ndarray = field(init=False)
    d: np.ndarray = field(init=False)

    def __post_init__(self) -> None:
        """检查输入数据，并初始化 K、f、d 和 LM。"""
        if self.nen != 2:
            raise ValueError("本程序只支持二节点杆/桁架单元，即 nen = 2。")
        if self.ndof not in (1, 2, 3):
            raise ValueError("每个节点自由度数 ndof 必须为 1、2 或 3。")
        if self.nsd != self.ndof:
            raise ValueError("本杆/桁架程序要求空间维数 nsd 与每节点自由度数 ndof 相同。")
        if self.IEN.shape != (self.nel, self.nen):
            raise ValueError(f"IEN 的形状应为 ({self.nel}, {self.nen})。")
        if self.coords.shape != (self.nnp, self.nsd):
            raise ValueError(f"节点坐标 coords 的形状应为 ({self.nnp}, {self.nsd})。")

        self.neq = self.ndof * self.nnp
        self.K = np.zeros((self.neq, self.neq), dtype=float)
        self.f = np.zeros(self.neq, dtype=float)
        self.d = np.zeros(self.neq, dtype=float)
        self.LM = self.make_LM()

        # 把给定节点力散布到总体荷载列阵 f 中。
        for dof, value in zip(self.force_dof, self.force_value):
            self._check_dof(dof)
            self.f[dof - 1] += float(value)

        # 把给定位移写入总体位移列阵 d 的相应位置。
        for dof, value in zip(self.fixed_dof, self.fixed_value):
            self._check_dof(dof)
            self.d[dof - 1] = float(value)

    def _check_dof(self, dof: int) -> None:
        """检查自由度号是否在 1..neq 范围内。"""
        if int(dof) < 1 or int(dof) > self.neq:
            raise ValueError(f"自由度号 {dof} 超出有效范围 1..{self.neq}。")

    def make_LM(self) -> np.ndarray:
        """根据单元连接数组 IEN 自动生成 LM 对号矩阵。"""
        LM = np.zeros((self.nen * self.ndof, self.nel), dtype=int)
        for e in range(self.nel):
            for j in range(self.nen):
                node = int(self.IEN[e, j])
                if node < 1 or node > self.nnp:
                    raise ValueError(f"第 {e + 1} 个单元中的节点号 {node} 无效。")
                for m in range(self.ndof):
                    local_dof = j * self.ndof + m
                    global_dof = self.ndof * (node - 1) + m
                    LM[local_dof, e] = global_dof
        return LM

    @property
    def fixed_index(self) -> np.ndarray:
        """已知位移自由度的 0 基数组下标。"""
        return self.fixed_dof.astype(int) - 1

    @property
    def free_index(self) -> np.ndarray:
        """未知位移自由度的 0 基数组下标。"""
        fixed = set(self.fixed_index.tolist())
        return np.array([i for i in range(self.neq) if i not in fixed], dtype=int)


def _as_float_array(data: Any) -> np.ndarray:
    """把输入数据转为浮点型 NumPy 数组。"""
    return np.array(data, dtype=float)


def _as_int_array(data: Any) -> np.ndarray:
    """把输入数据转为整型 NumPy 数组。"""
    return np.array(data, dtype=int)


def read_model_json(filename: str | Path) -> FEMModel:
    """从 JSON 文件读取有限元模型。

    JSON 文件中的节点号和自由度号采用 1 基编号，便于和题目、课件对应；
    程序内部数组访问采用 Python/NumPy 的 0 基下标。
    """
    with open(filename, "r", encoding="utf-8") as f:
        data = json.load(f)

    nsd = int(data["nsd"])
    ndof = int(data["ndof"])
    nnp = int(data["nnp"])
    nel = int(data["nel"])
    nen = int(data.get("nen", 2))

    # 节点坐标既可以写成 coords，也可以按 x/y/z 分列给出。
    if "coords" in data:
        coords = _as_float_array(data["coords"])
    else:
        cols = [data["x"]]
        if nsd >= 2:
            cols.append(data["y"])
        if nsd >= 3:
            cols.append(data["z"])
        coords = np.column_stack([_as_float_array(c) for c in cols])

    return FEMModel(
        title=data.get("Title", data.get("title", "未命名有限元模型")),
        nsd=nsd,
        ndof=ndof,
        nnp=nnp,
        nel=nel,
        nen=nen,
        E=_as_float_array(data["E"]),
        area=_as_float_array(data["CArea"]),
        coords=coords,
        IEN=_as_int_array(data["IEN"]),
        fixed_dof=_as_int_array(data.get("fixed_dof", [])),
        fixed_value=_as_float_array(data.get("fixed_value", [])),
        force_dof=_as_int_array(data.get("force_dof", [])),
        force_value=_as_float_array(data.get("force_value", [])),
    )
