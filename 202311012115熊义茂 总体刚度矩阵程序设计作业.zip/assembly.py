"""总体刚度矩阵直接组装模块。"""
from __future__ import annotations

from typing import Callable

import numpy as np

from model import FEMModel


def assemble_element(model: FEMModel, e: int, ke: np.ndarray) -> None:
    """把第 e 个单元刚度矩阵 ke 累加到总体刚度矩阵 K 中。"""
    # LM 的第 e 列给出了该单元每个局部自由度对应的总体自由度号。
    # np.ix_(lm, lm) 形成行列下标的笛卡尔积，可一次性完成 K[LM, LM] += Ke。
    lm = model.LM[:, e]
    model.K[np.ix_(lm, lm)] += ke


def assemble_global_stiffness(model: FEMModel, element_stiffness_func: Callable[[FEMModel, int], np.ndarray]) -> np.ndarray:
    """逐单元计算并组装总体刚度矩阵。"""
    # 重新组装前先清零，避免多次运行时旧结果被重复累加。
    model.K[:, :] = 0.0
    for e in range(model.nel):
        ke = element_stiffness_func(model, e)
        assemble_element(model, e, ke)
    return model.K
