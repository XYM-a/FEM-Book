# 总体刚度矩阵组装与桁架结构求解

本工程实现 1D 杆单元、2D/3D 桁架杆单元的直接刚度法求解流程：前处理、单元分析、直接组装、缩减法求解、单元应力/轴力后处理。

## 文件结构

```text
main.py                 # 单个 JSON 算例入口
run_examples.py          # 运行两个必做验证算例
model.py                 # 数据读取、自由度编号、LM 生成
element.py               # 单元长度、方向余弦、单元刚度矩阵
assembly.py              # 直接组装 K[LM,LM] += Ke
solver.py                # 缩减法处理位移边界条件，求反力
postprocess.py           # 应力和轴力后处理
generate_report_docx.py   # 由 report.md 生成 Word 报告
examples/rod_1d.json     # 算例 1：一维两单元杆
examples/truss_2d.json   # 算例 2：二维两杆桁架
outputs/*.txt            # 已运行得到的文本结果
report.md / report.docx  # 作业报告（Word 格式）
```

## 运行环境

- Python 3.10 或更高版本
- NumPy

安装 NumPy：

```bash
pip install numpy
```

## 运行方法

运行单个算例：

```bash
python main.py examples/rod_1d.json
python main.py examples/truss_2d.json
```

运行两个验证算例并保存输出：

```bash
python run_examples.py
```

输出文件会保存到 `outputs/` 目录，结果文本使用中文标签。

## 输入文件编号规则

JSON 输入文件中的节点号和自由度号采用从 1 开始的编号，方便与教材/课件保持一致。程序内部使用 NumPy 的 0 基下标，在 `model.py` 中完成转换。报告输出同时给出内部 0 基 LM 和便于检查的 1 基 LM。源码中的主要说明、注释和程序运行结果均已改为中文。

## 主要结果

### 算例 1

- 总体刚度矩阵：

```text
[[ 100, -100,    0],
 [-100,  300, -200],
 [   0, -200,  200]]
```

- 位移：`d1 = 0`, `d2 = 0.1`, `d3 = 0.15`
- 节点 1 反力：`r1 = -10`，大小为 10，与外载平衡。

### 算例 2

- 节点 3 位移：`u3 = 38.284271`, `v3 = -10.000000`
- 单元 1 应力：`-10.000000`
- 单元 2 应力：`14.142136`
- 总体刚度矩阵对称，施加位移边界条件前奇异，缩减矩阵非奇异。

