"""杆单元/桁架单元的几何量和单元刚度矩阵计算。"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from model import FEMModel


@dataclass
class ElementInfo:
    """保存一个单元的长度、方向余弦和单元刚度矩阵。"""

    length: float
    direction_cosines: np.ndarray
    stiffness: np.ndarray


def element_info(model: FEMModel, e: int) -> ElementInfo:
    """计算第 e 个单元的长度、方向余弦和刚度矩阵。"""
    # 输入的 IEN 节点号为 1 基编号；访问 Python 数组时要减 1。
    node_ids = model.IEN[e, :] - 1
    x1 = model.coords[node_ids[0], :]
    x2 = model.coords[node_ids[1], :]

    # 单元从局部节点 1 指向局部节点 2，方向余弦由该向量归一化得到。
    dx = x2 - x1
    length = float(np.linalg.norm(dx))
    if length <= 0.0:
        raise ValueError(f"第 {e + 1} 个单元长度为零，请检查节点坐标。")

    gamma = dx / length
    const = model.E[e] * model.area[e] / length

    if model.ndof == 1:
        # 一维杆只有轴向自由度，单元刚度矩阵为 EA/L * [[1, -1], [-1, 1]]。
        ke = const * np.array([[1.0, -1.0], [-1.0, 1.0]])
        gamma = np.array([1.0])
    else:
        # 二维/三维桁架统一写成 gamma*gamma^T 的分块矩阵。
        block = np.outer(gamma, gamma)
        ke = const * np.block([[block, -block], [-block, block]])

    return ElementInfo(length=length, direction_cosines=gamma, stiffness=ke)


def element_stiffness(model: FEMModel, e: int) -> np.ndarray:
    """返回第 e 个单元的单元刚度矩阵。"""
    return element_info(model, e).stiffness
