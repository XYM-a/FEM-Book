#!/usr/bin/env python3
"""杆/桁架结构直接刚度法主程序。"""
from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np

from model import read_model_json
from element import element_info, element_stiffness
from assembly import assemble_global_stiffness
from solver import solve_by_reduction
from postprocess import compute_element_results


def fmt_array(a: np.ndarray) -> str:
    """把 NumPy 数组格式化为便于报告检查的字符串。"""
    return np.array2string(a, precision=6, suppress_small=True, floatmode="fixed")


def bool_cn(value: bool) -> str:
    """把布尔值转换为中文显示。"""
    return "是" if value else "否"


def run(data_file: str | Path) -> str:
    """读取一个 JSON 算例，完成组装、求解和后处理，并返回中文结果文本。"""
    model = read_model_json(data_file)
    assemble_global_stiffness(model, element_stiffness)
    solve = solve_by_reduction(model)
    elem_results = compute_element_results(model)

    lines: list[str] = []
    lines.append(f"算例标题：{model.title}")
    lines.append(f"输入文件：{data_file}")
    lines.append("")
    lines.append("LM 对号矩阵（程序内部 0 基自由度号）：")
    lines.append(fmt_array(model.LM))
    lines.append("LM 对号矩阵（报告检查用 1 基自由度号）：")
    lines.append(fmt_array(model.LM + 1))
    lines.append("")
    lines.append("单元矩阵与几何信息：")
    for e in range(model.nel):
        info = element_info(model, e)
        lines.append(f"单元 {e + 1}：长度 L = {info.length:.6f}，方向余弦 = {fmt_array(info.direction_cosines)}")
        lines.append(fmt_array(info.stiffness))
    lines.append("")
    lines.append("总体刚度矩阵 K：")
    lines.append(fmt_array(model.K))
    lines.append(f"K 是否对称：{bool_cn(np.allclose(model.K, model.K.T))}")
    lines.append(f"施加边界条件前矩阵秩：{solve.rank_before_bc} / {model.neq}")
    lines.append(f"施加边界条件前 K 是否奇异：{bool_cn(solve.is_singular_before_bc)}")
    lines.append(f"缩减矩阵秩：{solve.rank_after_bc} / {len(solve.free_dof_1based)}")
    lines.append(f"缩减矩阵是否非奇异：{bool_cn(solve.is_reduced_nonsingular)}")
    lines.append("")
    lines.append("总体位移 d（按 1 基自由度顺序输出）：")
    for i, val in enumerate(solve.displacement, start=1):
        lines.append(f"d{i} = {val:.6f}")
    lines.append("")
    lines.append("已知位移自由度上的约束反力：")
    for dof, val in zip(solve.fixed_dof_1based, solve.reaction_fixed):
        lines.append(f"r{int(dof)} = {val:.6f}")
    lines.append("")
    lines.append("单元应力与轴力：")
    for r in elem_results:
        lines.append(
            f"单元 {r.element}：长度 L = {r.length:.6f}，"
            f"方向余弦 = {fmt_array(r.direction_cosines)}，"
            f"应力 = {r.stress:.6f}，轴力 = {r.axial_force:.6f}"
        )

    return "\n".join(lines)


def main() -> None:
    """命令行入口：python main.py examples/rod_1d.json。"""
    parser = argparse.ArgumentParser(description="杆/桁架结构直接刚度法有限元求解程序。")
    parser.add_argument("data_file", help="JSON 模型输入文件")
    args = parser.parse_args()
    print(run(args.data_file))


if __name__ == "__main__":
    main()
