"""位移边界条件处理和总体方程求解。"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from model import FEMModel


@dataclass
class SolveResult:
    """保存缩减法求解得到的位移、反力和矩阵秩检查结果。"""

    displacement: np.ndarray
    reaction_full: np.ndarray
    reaction_fixed: np.ndarray
    free_dof_1based: np.ndarray
    fixed_dof_1based: np.ndarray
    rank_before_bc: int
    rank_after_bc: int
    is_singular_before_bc: bool
    is_reduced_nonsingular: bool


def solve_by_reduction(model: FEMModel, tol: float = 1e-10) -> SolveResult:
    """用缩减法处理给定位移边界条件并求解 K d = f + r。"""
    fixed = model.fixed_index
    free = model.free_index

    if len(fixed) != len(model.fixed_value):
        raise ValueError("fixed_dof 与 fixed_value 的长度必须相同。")

    # d_E 为已知位移，d_F 为未知位移。
    d = np.zeros(model.neq, dtype=float)
    d[fixed] = model.fixed_value

    # 缩减方程：K_FF d_F = f_F - K_FE d_E。
    K_FF = model.K[np.ix_(free, free)]
    K_FE = model.K[np.ix_(free, fixed)]
    rhs = model.f[free] - K_FE @ d[fixed]

    rank_before = int(np.linalg.matrix_rank(model.K, tol=tol))
    rank_after = int(np.linalg.matrix_rank(K_FF, tol=tol))
    is_singular_before = rank_before < model.neq
    is_reduced_nonsingular = rank_after == len(free)

    if not is_reduced_nonsingular:
        raise np.linalg.LinAlgError("缩减刚度矩阵 K_FF 奇异，约束不足或结构存在机构位移。")

    d[free] = np.linalg.solve(K_FF, rhs)
    model.d[:] = d

    # Kd 是与位移场平衡所需的总体节点力；反力 r = Kd - f。
    internal_force = model.K @ d
    reaction_full = internal_force - model.f
    reaction_fixed = reaction_full[fixed]

    return SolveResult(
        displacement=d,
        reaction_full=reaction_full,
        reaction_fixed=reaction_fixed,
        free_dof_1based=free + 1,
        fixed_dof_1based=fixed + 1,
        rank_before_bc=rank_before,
        rank_after_bc=rank_after,
        is_singular_before_bc=is_singular_before,
        is_reduced_nonsingular=is_reduced_nonsingular,
    )
