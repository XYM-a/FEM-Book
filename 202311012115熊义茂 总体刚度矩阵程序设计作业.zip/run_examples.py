#!/usr/bin/env python3
"""运行两个必做验证算例，并把中文结果保存到 outputs 目录。"""
from pathlib import Path

from main import run

ROOT = Path(__file__).resolve().parent
examples = [
    ROOT / "examples" / "rod_1d.json",
    ROOT / "examples" / "truss_2d.json",
]
OUT = ROOT / "outputs"
OUT.mkdir(exist_ok=True)

for f in examples:
    text = run(f)
    out_file = OUT / f"{f.stem}_output.txt"
    out_file.write_text(text, encoding="utf-8")
    print(f"已写入结果文件：{out_file}")
    print(text)
    print("\n" + "=" * 80 + "\n")
